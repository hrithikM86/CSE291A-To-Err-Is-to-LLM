from typing import List, Optional

def longest(strings: List[str]) -> Optional[str]:
    if not strings:
        return None
    
    longest_string = None
    max_length = 0
    
    for s in strings:
        if len(s) > max_length:
            longest_string = s
            max_length = len(s)
    
    return longest_string
