from typing import List

def parse_music(music_string: str) -> List[int]:
    durations = []
    if not music_string:
        return durations
    
    i = 0
    while i < len(music_string):
        if music_string[i] == 'o':
            durations.append(4)
            i += 1
        elif music_string[i:i+2] == 'o|':
            durations.append(2)
            i += 2
        elif music_string[i:i+2] == '.|':
            durations.append(1)
            i += 2
        else:
            i += 1
    
    return durations
