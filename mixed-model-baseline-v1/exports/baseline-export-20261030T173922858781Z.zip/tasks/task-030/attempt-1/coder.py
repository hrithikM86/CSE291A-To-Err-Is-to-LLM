def get_positive(l: list) -> list:
    # Initialize an empty list to store positive numbers
    positive_nums = []
    
    # Iterate through each number in the input list
    for num in l:
        # Check if the number is positive
        if num > 0:
            # Append the number to the positive_nums list
            positive_nums.append(num)
    
    # Return the list of positive numbers
    return positive_nums
