def fizz_buzz(n: int) -> int:
    if n < 1 or n > 10000:
        raise ValueError("Input must be between 1 and 10000")

    count = 0
    for i in range(1, n):
        if i % 11 == 0 or i % 13 == 0:
            count += str(i).count('7')

    return count
