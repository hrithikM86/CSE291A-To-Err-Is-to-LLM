def sort_even(l: list) -> list:
    if not l:
        return []
    
    even_elements = [l[i] for i in range(0, len(l), 2)]
    even_elements.sort()
    
    sorted_list = l[:]
    even_index = 0
    for i in range(0, len(l), 2):
        sorted_list[i] = even_elements[even_index]
        even_index += 1
    
    return sorted_list
