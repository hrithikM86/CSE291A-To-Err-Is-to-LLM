def triples_sum_to_zero(l: list) -> bool:
    if len(l) < 3:
        return False
    
    l.sort()
    
    for i in range(len(l) - 2):
        if i > 0 and l[i] == l[i - 1]:
            continue
        
        left, right = i + 1, len(l) - 1
        while left < right:
            current_sum = l[i] + l[left] + l[right]
            if current_sum == 0:
                return True
            elif current_sum < 0:
                left += 1
            else:
                right -= 1
    
    return False
