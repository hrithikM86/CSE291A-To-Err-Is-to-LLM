def incr_list(l: list) -> list:
    """
    Return list with elements incremented by 1.
    >>> incr_list([1, 2, 3])
    [2, 3, 4]
    >>> incr_list([5, 3, 5, 2, 3, 3, 9, 0, 123])
    [6, 4, 6, 3, 4, 4, 10, 1, 124]
    """
    if not isinstance(l, list):
        raise TypeError("Input must be a list")

    result = [x + 1 for x in l]
    return result
