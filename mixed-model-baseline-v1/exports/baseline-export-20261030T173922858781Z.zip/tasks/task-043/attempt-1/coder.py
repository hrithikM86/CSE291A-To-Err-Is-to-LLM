def pairs_sum_to_zero(l: list) -> bool:
    if len(l) < 2:
        return False
    
    seen = set()
    
    for num in l:
        if -num in seen:
            return True
        seen.add(num)
    
    return False
