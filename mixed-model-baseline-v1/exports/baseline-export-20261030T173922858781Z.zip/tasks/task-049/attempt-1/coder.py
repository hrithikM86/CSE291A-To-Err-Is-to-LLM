def modp(n: int, p: int) -> int:
    if n == 0:
        return 1
    if p == 1:
        return 0 if n > 0 else 1
    
    result = 1
    n_bin = bin(n)[2:]  # Convert n to binary string and remove the '0b' prefix
    
    for bit in n_bin:
        result = (result * result) % p  # Square result and take modulo p
        if bit == '1':
            result = (result * 2) % p  # Multiply by 2 if the current bit is set
    
    return result
