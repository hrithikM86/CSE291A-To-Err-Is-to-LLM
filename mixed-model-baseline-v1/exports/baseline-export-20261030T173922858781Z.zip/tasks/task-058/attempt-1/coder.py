def common(l1: list, l2: list) -> list:
    if not l1 or not l2:
        return []
    
    set1 = set(l1)
    set2 = set(l2)
    
    common_elements = set1.intersection(set2)
    return sorted(list(common_elements))
