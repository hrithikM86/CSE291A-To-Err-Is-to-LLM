def largest_prime_factor(n: int) -> int:
    """
    Return the largest prime factor of n. Assume n > 1 and is not a prime.
    >>> largest_prime_factor(13195)
    29
    >>> largest_prime_factor(2048)
    2
    """
    largest_factor = 2
    factor = 3

    while n % 2 == 0:
        n //= 2
        largest_factor = 2

    while factor * factor <= n:
        if n % factor == 0:
            n //= factor
            largest_factor = factor
        else:
            factor += 2

    if n > 1:
        largest_factor = n

    return largest_factor
