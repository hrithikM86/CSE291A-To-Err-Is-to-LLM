def sum_to_n(n: int) -> int:
    if n < 1 or n > 10000:
        raise ValueError("n must be within the range [1, 10000]")
    
    if n == 1:
        return 1
    
    return n * (n + 1) // 2
