from typing import List, Tuple

def find_closest_elements(numbers: List[float]) -> Tuple[float, float]:
    if len(numbers) < 2:
        raise ValueError("The list must contain at least two elements.")
    
    numbers.sort()
    
    closest_pair = (numbers[0], numbers[1])
    smallest_diff = abs(numbers[1] - numbers[0])
    
    for i in range(1, len(numbers) - 1):
        current_diff = abs(numbers[i + 1] - numbers[i])
        if current_diff < smallest_diff:
            smallest_diff = current_diff
            closest_pair = (numbers[i], numbers[i + 1])
    
    return closest_pair
