def prime_length(string: str) -> bool:
    if not string:
        return False
    length = len(string)
    if length == 1:
        return False
    if length <= 1:
        return False
    if length in [2, 3]:  # Corrected from [2, 3] to [2, 3] to include 2
        return True
    if length % 2 == 0 or length % 3 == 0:
        return False
    i = 5
    while i * i <= length:
        if length % i == 0 or length % (i + 2) == 0:
            return False
        i += 6
    return True
