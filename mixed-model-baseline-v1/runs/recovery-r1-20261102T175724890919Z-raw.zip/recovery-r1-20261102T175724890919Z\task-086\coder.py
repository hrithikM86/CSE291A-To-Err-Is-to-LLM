import re

def anti_shuffle(s: str) -> str:
    if not s:
        return s
    
    words = re.findall(r'\S+|\s+', s)
    result = []
    
    for word in words:
        if word.isspace():
            result.append(word)
        else:
            sorted_word = ''.join(sorted(word))
            result.append(sorted_word)
    
    return ''.join(result)
