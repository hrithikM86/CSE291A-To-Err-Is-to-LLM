def next_smallest(lst):
    if not lst:
        return None
    unique_elements = set(lst)
    if len(unique_elements) < 2:
        return None
    sorted_lst = sorted(unique_elements)
    if len(sorted_lst) < 2:
        return None
    return sorted_lst[1]
