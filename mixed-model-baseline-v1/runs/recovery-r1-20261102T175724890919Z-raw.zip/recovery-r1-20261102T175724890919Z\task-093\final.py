def encode(message: str) -> str:
    """
    Write a function that takes a message, and encodes in such a 
    way that it swaps case of all letters, replaces all vowels in 
    the message with the letter that appears 2 places ahead of that 
    vowel in the english alphabet. 
    Assume only letters. 
    
    Examples:
    >>> encode('test')
    'TGST'
    >>> encode('This is a message')
    'tHKS KS C MGSSCGG'
    """
    vowels = 'aeiou'
    encoded_message = ''
    
    for char in message:
        if char.isalpha():
            swapped_char = char.swapcase()
            if swapped_char in vowels:
                index = vowels.index(swapped_char.lower())
                new_char = vowels[(index + 2) % len(vowels)]
                encoded_message += new_char.upper() if swapped_char.isupper() else new_char
            else:
                encoded_message += swapped_char
        else:
            encoded_message += char
    
    return encoded_message
