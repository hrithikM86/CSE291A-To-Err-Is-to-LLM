def rounded_avg(n: int, m: int) -> str or int:
    if not (isinstance(n, int) and isinstance(m, int) and n > 0 and m > 0):
        raise ValueError("Both n and m must be positive integers.")
    
    if n > m:
        return -1
    
    total_sum = (n + m) * (m - n + 1) // 2
    count = m - n + 1
    average = total_sum // count
    
    # Handle halfway case by rounding to the nearest even integer
    if total_sum % count == count // 2:
        average += average % 2
    
    return bin(average)
