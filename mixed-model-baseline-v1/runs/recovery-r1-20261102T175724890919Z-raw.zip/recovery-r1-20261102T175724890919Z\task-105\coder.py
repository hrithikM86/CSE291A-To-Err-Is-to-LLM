def by_length(arr):
    valid_digits = [str(digit) for digit in arr if 1 <= digit <= 9]
    if not valid_digits:
        return []
    valid_digits.sort()
    valid_digits.reverse()
    digit_names = ["One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine"]
    result = [digit_names[int(digit) - 1] for digit in valid_digits]
    return result
