def even_odd_palindrome(n: int) -> tuple:
    def is_palindrome(num):
        return str(num) == str(num)[::-1]

    if n == 1:
        return (0, 1)
    if n == 2:
        return (1, 1)

    even_count = 0
    odd_count = 0

    for i in range(1, n + 1):
        if is_palindrome(i):
            if i % 2 == 0:
                even_count += 1
            else:
                odd_count += 1

    return (even_count, odd_count)
