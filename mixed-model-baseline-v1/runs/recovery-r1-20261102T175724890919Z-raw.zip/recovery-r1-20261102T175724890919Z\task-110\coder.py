def exchange(lst1, lst2):
    # Step 1: Check if lst1 is already even
    if all(x % 2 == 0 for x in lst1):
        return "YES"
    
    # Step 2: Check if lst2 contains only odd numbers
    if all(x % 2 != 0 for x in lst2):
        return "NO"
    
    # Step 3: Count odd numbers in lst1 and even numbers in lst2
    odd_count_lst1 = sum(x % 2 != 0 for x in lst1)
    even_count_lst2 = sum(x % 2 == 0 for x in lst2)
    
    # Step 4: Determine if exchange is possible
    if odd_count_lst1 <= even_count_lst2:
        return "YES"
    else:
        return "NO"
