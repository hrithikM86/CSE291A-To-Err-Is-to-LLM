def select_words(s: str, n: int) -> list:
    def count_consonants(word: str) -> int:
        consonants = "bcdfghjklmnpqrstvwxyzBCDFGHJKLMNPQRSTVWXYZ"
        return sum(1 for char in word if char in consonants)
    
    result = []
    words = s.split()
    
    for word in words:
        if word and count_consonants(word) == n:
            result.append(word)
    
    return result
