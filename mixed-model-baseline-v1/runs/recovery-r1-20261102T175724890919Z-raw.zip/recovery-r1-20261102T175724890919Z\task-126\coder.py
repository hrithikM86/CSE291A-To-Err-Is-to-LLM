def is_sorted(lst):
    if not lst or len(lst) == 1:
        return True
    
    for i in range(len(lst) - 1):
        current = lst[i]
        next_element = lst[i + 1]
        if current >= next_element:
            return False
    
    return True
