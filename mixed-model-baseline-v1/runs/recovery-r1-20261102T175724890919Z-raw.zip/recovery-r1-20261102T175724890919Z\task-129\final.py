import heapq

def minPath(grid, k):
    """
    Given a grid with N rows and N columns (N >= 2) and a positive integer k,
    each cell of the grid contains a value. Every integer in the range [1, N * N]
    inclusive appears exactly once on the cells of the grid.

    You have to find the minimum path of length k in the grid. You can start
    from any cell, and in each step you can move to any of the neighbor cells,
    in other words, you can go to cells which share an edge with you current
    cell. A path A (of length k) is considered less than a path B (of length k)
    if after making the ordered lists of the values on the cells that A and B go
    through (let's call them lst_A and lst_B), lst_A is lexicographically less
    than lst_B, in other words, there exist an integer index i (1 <= i <= k)
    such that lst_A[i] < lst_B[i] and for any j (1 <= j < i) we have
    lst_A[j] = lst_B[j]. It is guaranteed that the answer is unique.
    Return an ordered list of the values on the cells that the minimum path go through.

    Examples:
        Input: grid = [ [1,2,3], [4,5,6], [7,8,9]], k = 3
        Output: [1, 2, 1]

        Input: grid = [ [5,9,3], [4,1,6], [7,8,2]], k = 1
        Output: [1]
    """
    N = len(grid)
    if N < 2 or k < 1:
        raise ValueError("Grid must be at least 2x2 and k must be a positive integer")

    directions = [(-1, 0), (1, 0), (0, -1), (0, 1)]
    pq = []

    for i in range(N):
        for j in range(N):
            heapq.heappush(pq, ((grid[i][j],), i, j))

    while pq:
        path, x, y = heapq.heappop(pq)
        if len(path) == k:
            return list(path)

        for dx, dy in directions:
            nx, ny = x + dx, y + dy
            if 0 <= nx < N and 0 <= ny < N:
                heapq.heappush(pq, ((path + (grid[nx][ny],), nx, ny)))
