def is_nested(string: str) -> bool:
    depth = 0
    has_nested = False

    for c in string:
        if c == '[':
            depth += 1
        elif c == ']':
            depth -= 1

        if depth > 0:
            has_nested = True

        if depth < 0:
            return False

    return has_nested and depth == 0
