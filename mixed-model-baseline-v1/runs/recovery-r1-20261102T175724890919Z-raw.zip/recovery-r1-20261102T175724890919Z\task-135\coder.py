def can_arrange(arr):
    # Function body
    if not arr or len(arr) == 1:
        return -1
    
    for i in range(len(arr) - 1, 0, -1):
        if arr[i] < arr[i - 1]:
            return i
    
    return -1
