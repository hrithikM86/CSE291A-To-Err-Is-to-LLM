def is_equal_to_sum_even(n: int) -> bool:
    """
    Evaluate whether the given number n can be written as the sum of exactly 4 positive even numbers
    """
    # Input Validation
    if not (1 <= n <= 10000):
        return False

    # Edge Cases
    if n < 8:
        return False
    if n % 2 != 0:
        return False

    # General Case
    if n == 8:
        return True
    if (n - 8) % 2 == 0 and (n - 8) >= 0:
        return True

    return False
