def sum_squares(lst):
    total_sum = 0
    for i, val in enumerate(lst):
        if i % 3 == 0:
            total_sum += val ** 2
        elif i % 4 == 0:
            total_sum += val ** 3
        else:
            total_sum += val
    return total_sum
