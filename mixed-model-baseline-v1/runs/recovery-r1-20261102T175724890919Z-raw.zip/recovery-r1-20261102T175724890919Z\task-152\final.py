def compare(game, guess):
    """
    I think we all remember that feeling when the result of some long-awaited
    event is finally known. The feelings and thoughts you have at that moment are
    definitely worth noting down and comparing.
    Your task is to determine if a person correctly guessed the results of a number of matches.
    You are given two arrays of scores and guesses of equal length, where each index shows a match.
    Return an array of the same length denoting how far off each guess was. If they have guessed correctly,
    the value is 0, and if not, the value is the absolute difference between the guess and the score.
    """

    if not isinstance(game, list) or not isinstance(guess, list):
        raise ValueError("Both game and guess must be lists.")
    if len(game) != len(guess):
        raise ValueError("Both lists must be of equal length.")

    result = []
    for i in range(len(game)):
        difference = abs(game[i] - guess[i])
        result.append(difference)

    return result
