import math

def max_fill(grid, capacity):
    if not grid or not all(len(row) == len(grid[0]) for row in grid):
        raise ValueError("Invalid grid input")

    total_drops = 0

    for well in grid:
        drops = math.ceil(well.count(1) / capacity)
        total_drops += drops

    return total_drops
