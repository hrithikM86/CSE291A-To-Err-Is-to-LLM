import math

def x_or_y(n: int, x: int, y: int) -> int:
    if n < 2:
        return y
    if n == 2:
        return x
    for i in range(2, int(math.sqrt(n)) + 1):
        if n % i == 0:
            return y
    return x
