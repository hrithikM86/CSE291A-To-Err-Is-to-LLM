def decimal_to_binary(decimal: int) -> str:
    if not isinstance(decimal, int) or decimal < 0:
        raise ValueError("Input must be a non-negative integer.")
    
    if decimal == 0:
        return "db00000000db"
    
    binary_digits = bin(decimal)[2:]
    padded_digits = binary_digits.zfill(8)
    return f"db{padded_digits}db"
