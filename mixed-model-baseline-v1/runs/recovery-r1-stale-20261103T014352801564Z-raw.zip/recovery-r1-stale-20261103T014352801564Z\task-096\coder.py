def count_up_to(n: int) -> list:
    if n <= 2:
        return []
    
    def is_prime(num: int) -> bool:
        if num <= 1:
            return False
        if num == 2:
            return True
        if num % 2 == 0:
            return False
        for i in range(3, int(num**0.5) + 1, 2):
            if num % i == 0:
                return False
        return True
    
    primes = []
    for num in range(3, n, 2):
        if is_prime(num):
            primes.append(num)
    
    return primes
