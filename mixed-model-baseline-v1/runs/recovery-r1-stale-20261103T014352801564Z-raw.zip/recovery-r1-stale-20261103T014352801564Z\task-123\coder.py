def get_odd_collatz(n: int) -> list:
    if n <= 0:
        raise ValueError("Input must be a positive integer")
    
    odd_numbers = []
    current = n
    
    while current != 1:
        if current % 2 != 0:
            odd_numbers.append(current)
        current = current // 2 if current % 2 == 0 else 3 * current + 1
    
    if 1 not in odd_numbers:
        odd_numbers.append(1)
    
    return odd_numbers
